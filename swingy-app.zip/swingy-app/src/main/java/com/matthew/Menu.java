package com.matthew;

import java.util.Scanner;

/**
 * Hello world!
 *
 */
public class Menu {
    boolean exit;

    public static void main(String[] args) {
        Menu menu = new Menu();
        menu.runMenu();
    }

    public void runMenu() {
        printHeader();
        while (!exit) {
            printMenu();
            int choice = getInput();
            performAction(choice);


        }
    }


    private void printHeader() {
        System.out.println("|+---------------------------+|");
        System.out.println("|      Welcome to             |");
        System.out.println("|         Swingy              |");
        System.out.println("|+---------------------------+|");
    }

    private void printMenu() {
        System.out.println("\nMake a selection:        ");
        System.out.println("1) Create Character");
        System.out.println("2) Select created characters");
        System.out.println("3) Load Game                 ");
        System.out.println("4) New Game                  ");
        System.out.println("5) Exit");

    }

    private int getInput() {
        Scanner kb = new Scanner(System.in);
        int choice = -1;
        while(choice < 0 || choice > 4){
            try{
                    System.out.println("\nEnter your choice:");
                    choice = Integer.parseInt(kb.nextLine());
            }
            catch (NumberFormatException e){
                     System.out.println("Invalid selection.Please try again");

            }

        }
        return choice;
        }
        private void performAction(){
        switch(choice){
            case 5:
                exit = true;
                System.out.println("");
                break;
            case 1:

            case 2:

            case 3:

            case 4:

            default:
        }
        }
}

